package com.empresa.proyecto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.empresa.proyecto.bean.TipoCuenta;
import com.empresa.proyecto.util.JDBCutil;
import com.mysql.cj.xdevapi.PreparableStatement;

public class TipoCuentaDaoImpl implements ITipoCuentaDao{

	public JDBCutil db;
	
	public TipoCuentaDaoImpl() {
		db= new JDBCutil();
	}

	@Override
	public List<TipoCuenta> list() {
		
		List<TipoCuenta> list= null;
		String strSql = "select t.id_tipocuenta, t.desc_tipocuenta from tb_tipocuenta t";
		System.out.println("strSql: "+strSql);
		
		try {
			Connection cn= db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			ResultSet rs = st.executeQuery();
			list = new ArrayList<>();
			while (rs.next()) {
				TipoCuenta tipo = new TipoCuenta();
				tipo.setId_tipoCuenta(rs.getInt("id_tipocuenta"));
				tipo.setDescTipoCuenta(rs.getString("desc_tipocuenta"));
				list.add(tipo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}

}
