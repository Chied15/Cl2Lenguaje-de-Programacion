package com.empresa.proyecto.dao;

import java.util.List;

import com.empresa.proyecto.bean.TipoCuenta;

public interface ITipoCuentaDao {
	
List<TipoCuenta> list();
}
