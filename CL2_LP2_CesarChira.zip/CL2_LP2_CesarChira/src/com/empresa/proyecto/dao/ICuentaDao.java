package com.empresa.proyecto.dao;

import java.util.List;

import com.empresa.proyecto.bean.Cuenta;

public interface ICuentaDao {
		List<Cuenta> list();

		int insert(Cuenta cuenta);

		int update(Cuenta cuenta);

		Cuenta find(Cuenta cuenta);
	
}
