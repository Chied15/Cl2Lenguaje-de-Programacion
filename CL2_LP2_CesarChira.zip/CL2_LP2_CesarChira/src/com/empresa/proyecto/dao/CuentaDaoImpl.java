package com.empresa.proyecto.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.empresa.proyecto.bean.Cuenta;
import com.empresa.proyecto.util.JDBCutil;

public class CuentaDaoImpl implements ICuentaDao {

	public JDBCutil db;

	public CuentaDaoImpl() {
		this.db = new JDBCutil();
	}

	@Override
	public List<Cuenta> list() {

		List<Cuenta> list = null;
		String strSql = "SELECT c.id_cuenta, c.num_cuenta, c.cliente, c.monto, c.id_tipocuenta,t.desc_tipocuenta  fROM tb_cuenta c inner join tb_tipocuenta t on c.id_tipocuenta=t.id_tipocuenta order by c.id_cuenta";
		System.out.println("strSql: " + strSql);

		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			ResultSet rs = st.executeQuery();
			list = new ArrayList<>();
			while (rs.next()) {
				Cuenta c = new Cuenta();
				c.setId_cuenta(rs.getInt("id_cuenta"));
				c.setNumCuenta(rs.getString("num_cuenta"));
				c.setCliente(rs.getString("cliente"));
				c.setMonto(rs.getDouble("monto"));
				c.setId_tipoCuenta(rs.getInt("id_tipocuenta"));
				c.setDescTipoCuenta(rs.getString("desc_tipocuenta"));
				
				
				list.add(c);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int insert(Cuenta cuenta) {
		int numRes = 0;

		String strSql = "insert into tb_cuenta (num_cuenta, cliente, monto, id_tipocuenta) values" + " ( " + "'"
				+ cuenta.getNumCuenta() + "' , " + "'" + cuenta.getCliente() + "' , " + cuenta.getMonto() + " , "
				+ cuenta.getId_tipoCuenta() + " ) ";
		System.out.println("strSql: " + strSql);

		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			numRes = st.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return numRes;
	}

	@Override
	public int update(Cuenta cuenta) {
		int numRes = 0;
		String strSql = "update tb_cuenta set " 
				+ " num_cuenta = '" + cuenta.getNumCuenta() + "'," 
				+ " cliente = '"	+ cuenta.getCliente() + "'," 
				+ " monto = " + cuenta.getMonto() + "," 
				+ " id_tipocuenta = "+ cuenta.getId_tipoCuenta() 
				+ " where id_cuenta=" + cuenta.getId_cuenta();
		System.out.println("strSql: " + strSql);
		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			numRes = st.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return numRes;
	}

	@Override
	public Cuenta find(Cuenta cuenta) {
		Cuenta c = null;
		String strSql = "SELECT c.id_cuenta, c.num_cuenta, c.cliente, c.monto, c.id_tipocuenta  " + "FROM tb_cuenta c  "
				+ "where c.id_cuenta = " + cuenta.getId_cuenta();
		System.out.println("strSql: " + strSql);

		try {
			Connection cn = db.getConexion();
			PreparedStatement st = cn.prepareStatement(strSql);
			ResultSet rs = st.executeQuery();
			c = new Cuenta();
			while (rs.next()) {
				c.setId_cuenta(rs.getInt("id_cuenta"));
				c.setNumCuenta(rs.getString("num_cuenta"));
				c.setCliente(rs.getString("cliente"));
				c.setMonto(rs.getDouble("monto"));
				c.setId_tipoCuenta(rs.getInt("id_tipocuenta"));
				
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return c;
	}

}
