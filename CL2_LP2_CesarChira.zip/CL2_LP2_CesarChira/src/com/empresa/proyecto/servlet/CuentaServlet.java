package com.empresa.proyecto.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.empresa.proyecto.bean.Cuenta;
import com.empresa.proyecto.bean.TipoCuenta;
import com.empresa.proyecto.service.CuentaServiceImpl;
import com.empresa.proyecto.service.ICuentaService;
import com.empresa.proyecto.service.ITipoCuentaService;
import com.empresa.proyecto.service.TipoCuentaServiceImpl;

@WebServlet("/CuentaServlet")
public class CuentaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final ICuentaService cuentaService;
	private final ITipoCuentaService tipoCuentaService;
	public CuentaServlet() {
		cuentaService = new CuentaServiceImpl();
		tipoCuentaService = new TipoCuentaServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String strAccion = request.getParameter("accion");
		String strIdCuenta = request.getParameter("idCuenta");
		System.out.println("strAccion" + strAccion);
		System.out.println("strIdCuenta" + strIdCuenta);
		
		switch (strAccion) {
		case "listar":
			listarCuentas(request, response);
			break;
		case "nuevo":
			mostrarForm(request, response,0);
			break;
		case "guardar":
			guardarCuentas(request, response);
			break;
		case "editar":
			mostrarForm(request, response,Integer.parseInt(strIdCuenta));
			break;
			

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	private void listarCuentas(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Entrando al metodo listarCuentas");
		try {
			List<Cuenta> listCuentas = cuentaService.listar();
			System.out.println("listCuentas.size" + listCuentas.size());
			RequestDispatcher dispatcher = request.getRequestDispatcher("cuenta.jsp");
			request.setAttribute("listCuentas", listCuentas);
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void mostrarForm(HttpServletRequest request, HttpServletResponse response, int idCuenta) {
		System.out.println("Entrando al metodo mostrarform");
		try {
			
			List<TipoCuenta> tipoList = tipoCuentaService.listar();
			System.out.println("tipoList.size:"+tipoList.size());
			request.setAttribute("tipoList", tipoList);
			Cuenta c= new Cuenta();
			c.setId_cuenta(idCuenta);
			Cuenta cuentaEdit = null;
			if(idCuenta>0) {
				cuentaEdit=cuentaService.buscar(c);
			}else {
				cuentaEdit = new Cuenta();
				cuentaEdit.setNumCuenta("");
			}
			request.setAttribute("cuentaEdit", cuentaEdit);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("cuenta_form.jsp");
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void guardarCuentas(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Entrando al metodo guardarform");
		Cuenta cuenta = new Cuenta();
		
		cuenta.setNumCuenta(request.getParameter("txtnumCuenta"));
		cuenta.setCliente(request.getParameter("txtcliente"));
		cuenta.setMonto(Double.parseDouble(request.getParameter("txtmonto")));
		cuenta.setId_tipoCuenta(Integer.parseInt(request.getParameter("cboRoles")));
		int numRes;
		try {
			numRes = cuentaService.guardar(cuenta);
			if (numRes > 0) {
				listarCuentas(request, response);
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
