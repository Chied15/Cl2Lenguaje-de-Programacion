package com.empresa.proyecto.service;

import java.util.List;

import com.empresa.proyecto.bean.TipoCuenta;
import com.empresa.proyecto.dao.ITipoCuentaDao;
import com.empresa.proyecto.dao.TipoCuentaDaoImpl;

public class TipoCuentaServiceImpl implements ITipoCuentaService{

	private ITipoCuentaDao dao;
	
	public TipoCuentaServiceImpl() {
		dao = new TipoCuentaDaoImpl();
	}
	@Override
	public List<TipoCuenta> listar() throws Exception {
		return dao.list();
	}

}
