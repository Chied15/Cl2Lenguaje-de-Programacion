package com.empresa.proyecto.service;

import java.util.List;

import com.empresa.proyecto.bean.Cuenta;

public interface ICuentaService {
		List<Cuenta> listar () throws Exception;

		int guardar(Cuenta cuenta) throws Exception;

		Cuenta buscar(Cuenta cuenta) throws Exception;
}
