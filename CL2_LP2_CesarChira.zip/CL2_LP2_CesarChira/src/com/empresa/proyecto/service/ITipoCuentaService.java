package com.empresa.proyecto.service;

import java.util.List;

import com.empresa.proyecto.bean.TipoCuenta;

public interface ITipoCuentaService {
	List<TipoCuenta> listar() throws Exception;
}
