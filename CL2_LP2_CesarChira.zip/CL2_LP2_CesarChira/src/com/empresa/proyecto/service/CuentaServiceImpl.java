package com.empresa.proyecto.service;

import java.util.List;

import com.empresa.proyecto.bean.Cuenta;
import com.empresa.proyecto.dao.CuentaDaoImpl;
import com.empresa.proyecto.dao.ICuentaDao;

public class CuentaServiceImpl implements ICuentaService{
	
	ICuentaDao dao;

	public CuentaServiceImpl() {
		dao = new CuentaDaoImpl();
	}

	@Override
	public List<Cuenta> listar() throws Exception {
		
		return dao.list();
	}

	@Override
	public int guardar(Cuenta cuenta) throws Exception {
		if(cuenta.getId_cuenta()<1) {
			return dao.insert(cuenta);
		}else {
			return dao.update(cuenta);
		}
		
	}

	@Override
	public Cuenta buscar(Cuenta cuenta) throws Exception {
		return dao.find(cuenta);
	}
	
	
}
