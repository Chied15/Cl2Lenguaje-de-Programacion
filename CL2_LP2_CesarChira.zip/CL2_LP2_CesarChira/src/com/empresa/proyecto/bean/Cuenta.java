package com.empresa.proyecto.bean;

public class Cuenta {

	private int id_cuenta;
	private String numCuenta;
	private String cliente;
	private double monto;
	private int id_tipoCuenta;
	private String descTipoCuenta;
	
	public Cuenta() {
		super();
	}

	public int getId_cuenta() {
		return id_cuenta;
	}

	public void setId_cuenta(int id_cuenta) {
		this.id_cuenta = id_cuenta;
	}

	public String getNumCuenta() {
		return numCuenta;
	}

	public void setNumCuenta(String numCuenta) {
		this.numCuenta = numCuenta;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public double getMonto() {
		return monto;
	}

	public void setMonto(double monto) {
		this.monto = monto;
	}

	public int getId_tipoCuenta() {
		return id_tipoCuenta;
	}

	public void setId_tipoCuenta(int id_tipoCuenta) {
		this.id_tipoCuenta = id_tipoCuenta;
	}

	public String getDescTipoCuenta() {
		return descTipoCuenta;
	}

	public void setDescTipoCuenta(String descTipoCuenta) {
		this.descTipoCuenta = descTipoCuenta;
	}
	
	 
}
