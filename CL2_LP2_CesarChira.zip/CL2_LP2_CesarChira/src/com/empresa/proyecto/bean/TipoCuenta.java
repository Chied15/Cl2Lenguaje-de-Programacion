package com.empresa.proyecto.bean;

public class TipoCuenta {
	private int id_tipoCuenta;
	private String descTipoCuenta;
	
	public TipoCuenta() {
		super();
	}
	public int getId_tipoCuenta() {
		return id_tipoCuenta;
	}
	public void setId_tipoCuenta(int id_tipoCuenta) {
		this.id_tipoCuenta = id_tipoCuenta;
	}
	public String getDescTipoCuenta() {
		return descTipoCuenta;
	}
	public void setDescTipoCuenta(String descTipoCuenta) {
		this.descTipoCuenta = descTipoCuenta;
	}

}
