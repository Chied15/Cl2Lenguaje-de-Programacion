package com.empresa.proyecto.util;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.cj.jdbc.DatabaseMetaData;

import java.sql.Connection;

public class JDBCutil {

	String ConxBD = "jdbc:mysql://localhost:3306/inversionesbd?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	String JdbcBD = "com.mysql.cj.jdbc.Driver";

	String UserBD = "root";
	String PassBD = "Cs9pquei";

	Connection Conexion;

	public JDBCutil() {

		try {
			Class.forName(JdbcBD);
			Conexion = DriverManager.getConnection(ConxBD, UserBD, PassBD);
			if (Conexion != null) {
				DatabaseMetaData dm = (DatabaseMetaData) Conexion.getMetaData();
				System.out.println(this.getClass().getName() + " : Conexion con BD Establecida..");

			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Connection getConexion() {
		return this.Conexion;
	}

	public static void main(String[] args) {
		JDBCutil Cn = new JDBCutil();
	}

}
